// ------------------------------------------------
// GROUP 06 

// ANSHIKA GUPTA 2020A7PS0111P
// NIVEDITHA KOVILAKATH 2020A7PS0067P
// SHAZ 2020A7PS0025P
// SARTHAK AGARWAL 2020A7PS0112P
// SHREYAS SESHAM 2020A7PS1684P
// ------------------------------------------------


#ifndef PARSERDEF_H
#define PARSERDEF_H

#include "ll1_gram.h"   
// #include "adtDef.h"
//array of LHS grammar G 
//array of follow and first
stack* parserStack;
parse_tree* parseTree;
token * L;

#endif